package org.zerock;

import org.zerock.mail.MailSendUI;

public class Main {

    public static void main(String[] args) {

        MailSendUI ui = new MailSendUI();
        ui.input();


    }
}
